﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    class Fireball : Spell
    {
        public Fireball(string publicSpellName, string publicSpellDescription) : base(publicSpellName, publicSpellDescription)
        {
            publicSpellName = "fireBall";
            publicSpellDescription = "Imemememanimo";
        }
        public int spellCooldown
        {
            get
            {
                return spellCooldown;
            }
        }
        public override void Spelling(Character target)
        {   
            RoundsJournal.fireballDid();
            RoundsJournal.damageCounter(30);
            target.applyDamage(30);
            Random random = new Random();
            if (random.Next(0, 100) < 50)
            {
                Burning BurnEffect = new Burning("Burning", 3);
                target.effectadditive(BurnEffect, target);
                Console.WriteLine($"{target.Name} начинает гореть, теряя 5 ед. Здоровья каждый ход!");
            }
        }
    }
}
