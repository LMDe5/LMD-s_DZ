﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    class Heal : Spell
    {
        public Heal(string publicSpellName, string publicSpellDescription) : base(publicSpellName, publicSpellDescription)
        {
            publicSpellName = "Heal";
            publicSpellDescription = "It can heal you :D";
        }
        public override void Spelling(Character target)
        {
            RoundsJournal.healDid();
            RoundsJournal.healCounter(15);
            target.applyHealth(15);
        }
    }
}
