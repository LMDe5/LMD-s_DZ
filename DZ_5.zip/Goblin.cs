﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Goblin : Character
    {
        public Goblin(string publicName, int publicHealth, int publicMaxHealth) : base(publicName, publicHealth, publicMaxHealth)
        {
        }

        public override void applyDamage(int damage)
        {
            RoundsJournal.goblinAttack();
            int newDamage = damage - 1;
            base.applyDamage(newDamage);
        }
    }
}
