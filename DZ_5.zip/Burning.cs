﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Burning : Effect
    {
        public Burning(string newEffectName, int newEffectTime) : base(newEffectName, newEffectTime)
        {
            newEffectName = "Burning";
            newEffectTime = 3;
        }
        public override void EffectBegin(Character target)
        {
            Console.WriteLine($"{target.Name} начинает гореть!");
        }
        public override void EffectDoWork(Character target)
        {
            target.applyDamage(5);
            Console.WriteLine($"{target.Name} получает 5 урона, горя!");
        }
        public override void EffectEnd(Character target)
        {
            Console.WriteLine($"{target.Name} перестает гореть!");
        }
    }
}
