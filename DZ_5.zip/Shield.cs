﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    class Shield : Spell
    {
        public Shield(string publicSpellName, string publicSpellDiscription) : base(publicSpellName, publicSpellDiscription)
        {
            publicSpellName = "Shield";
            publicSpellDiscription = "It can protect you a lil bit";
        }
        public override void Spelling(Character target)
        {
            RoundsJournal.shieldDid();
            target.ApplyShield(2, 0.5f);
            Shielded shieldEffect = new Shielded("Shield", 3);
            target.effectadditive(shieldEffect, target);
        }
    }
}
