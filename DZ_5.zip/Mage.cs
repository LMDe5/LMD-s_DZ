﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Mage : Character
    {
        Spell[] spellBook = new Spell[3]
        {
                new Fireball("fireBall", "ImememeManiMo"),
                new Shield("shield", "it can protect you a lil bit"),
                new Heal("Healling", "It gives you 15 HP")
        };
        Spell[] cooldownSpells = new Spell[3];

        private string mageName;
        private int mageHealth;
        private int mageMaxHealth;

        public string MageName => mageName;
        public int MageHealth => mageHealth;
        public int MageMaxHealth => mageMaxHealth;

        public Mage(string publicName, int publicHealth, int publicMaxHealth) : base(publicName, publicHealth, publicMaxHealth)
        {
        }

        public override void applyHealth(int NewHealth)
        {
            base.applyHealth(NewHealth);
        }

        public override void applyDamage(int damage)
        {
            base.applyDamage(damage);
        }

        public void showSpellBook()
        {
            for (int i = 0; i < spellBook.Length; i++)
            {
                if (spellBook[i] != null)
                {
                    Console.WriteLine("заклинание под номером " + (i + 1));
                    spellBook[i].spellShowInfo();
                }
            }
        }

        public void processCooldown(int choisedSpell)
        {
            if (cooldownSpells.Length > 0)
            {
                for (int i = 0; i < cooldownSpells.Length; i++)
                {
                    for (int j = 0; j < spellBook.Length; j++)
                    {
                        if (cooldownSpells[i] != null && spellBook[j] == null)
                        {
                            spellBook[j] = cooldownSpells[i];
                            cooldownSpells[i] = null;
                        }
                    }
                }
            }

            for (int i = 0;i < spellBook.Length; i++)
            {
                if (cooldownSpells[i] == null)
                {
                    cooldownSpells[i] = spellBook[choisedSpell - 1];
                    spellBook[choisedSpell - 1] = null;
                    Console.WriteLine($"Spell под номером {choisedSpell} уходит на перезарядку!");
                    return;
                }
            }
        }

        public void spellingSpellBook(int choisedSpell, Character target)
        {
            if (choisedSpell < 1 || choisedSpell > spellBook.Length)
            {
                Console.WriteLine("Введен неверный формат выбора заклинания!");
                return;
            }
            int spellIndex = choisedSpell - 1;
            Spell spell = spellBook[spellIndex];
            if (spellBook[spellIndex] == null)
            {
                Console.WriteLine("Введен неверный формат выбора заклинания! Вы будете наказаны! Пропуск хода!");
                return;
            }
            Console.WriteLine($"Было выбрано заклинание под номером {choisedSpell}!");
            spell.Spelling(target);
            processCooldown(choisedSpell);
        }
    }
}