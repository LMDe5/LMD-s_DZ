﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Shielded : Effect
    {
        public Shielded(string newEffectName, int newEffectTime) : base(newEffectName, newEffectTime)
        {
            newEffectName = "Shielded";
            newEffectTime = 3;
        }
        public override void EffectBegin(Character target)
        {
            Console.WriteLine($"Щит был выдан на {target.ShieldTime} хода!");
        }
        public override void EffectDoWork(Character target)
        {
            Console.WriteLine($"Щит продержится еще {target.ShieldTime} хода!");
        }
        public override void EffectEnd(Character target)
        {
            Console.WriteLine($"{target.Name} потерял щит в бою!");
        }
    }
}
