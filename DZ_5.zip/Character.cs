﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    abstract class Character
    {
        protected string name;
        protected int health;
        protected int maxHealth;
        protected bool isAlive;
        protected float shield;
        protected int shieldTime;

        private Effect[] effects = new Effect[3];
        int effectsCount = 0;
        public void effectadditive(Effect effect, Character target)
        {
            if (effectsCount < effects.Length)
            {
                effects[effectsCount] = effect;
                effectsCount++;
                effect.EffectBegin(target);
            }
        }
        public void ProcessEffects(Character target)
        {
            for (int i = 0; i < effects.Length; i++)
            {
                if (effects[i] != null)
                {
                    effects[i].IsWorking(target);
                }
            }
            ExparedEffects();
        }
        public void ExparedEffects()
        {
            for (int i = 0; i < effects.Length;i++)
            {
                if (effects[i] != null && effects[i].publicEffectTime <= 0)
                {
                    effects[i] = null;
                }
            }
        }
        public void ShowEffects(Character target)
        {
            if (effectsCount == 0)
            {
                Console.WriteLine($"{Name} не обладает эффектами!");
                return;
            }
            for (int i = 0; i < effects.Length;i++)
            {
                if (effects[i] != null)
                {
                    Console.WriteLine($"{Name} имеет эффект {effects[i].publicEffectName}!");
                    Console.WriteLine($"У {Name} осталось действие эффекта на {effects[i].publicEffectTime} раундов!");
                }
            }
        }

        public int Health
        {
            get
            { return health; }
        }
        public string Name
        {
            get
            {
                return name; 
            }
        }
        public float Shield
        {
            get
            {
                return shield;
            }
        }
        public int ShieldTime
        {
            get
            {
                return shieldTime;
            }
        }

        public Character(string publicName, int publicHealth, int publicMaxHealth)
        {
            name = publicName;
            health = publicHealth;
            maxHealth = publicMaxHealth;
            isAlive = true;
            shield = 0f;
            shieldTime = 0;
        }

        public virtual void applyDamage(int damage)
        {
            if (shield > 0)
            {
                float Newdamage = shield * damage;
                health -= (int)Newdamage;
                Console.WriteLine($"Игроку {Name} нанесли урон, но щит поглотил часть! Его здоровье равняется: {health}");
                shieldTime -= 1;
                if (shieldTime <= 0)
                {
                    shield = 0f;
                    Console.WriteLine($"Щит {Name} иссяк!");
                }
                return;
            }
            if (health <= 0)
            {
                Console.WriteLine($"{Name} умер!");
                isAlive = false;
            }
            else
            {
                health -= damage;
                Console.WriteLine($"Игроку {Name} нанесли урон! Его здоровье равняется: {health}");
            }
        }
        public virtual void applyHealth(int NewHealth)
        {
            if (health + NewHealth > maxHealth)
            {
                health = maxHealth;
                Console.WriteLine($"Игрок {Name} восстановили здоровье до полного значения ({maxHealth})!");
            }
            else
            {
                health = health + NewHealth;
                Console.WriteLine($"Игрок {Name} восстановили здоровье, оно равняется: {health}!");
            }
        }
        public virtual void ApplyShield(int NewShieldTime, float NewShieldHelp)
        {
            shield = NewShieldHelp;
            shieldTime = NewShieldTime;
            Console.WriteLine($"{Name} получил щит! Задерживая 50% урона!");
        }
    }
}
