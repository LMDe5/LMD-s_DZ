﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    abstract class Effect
    {
        protected string EffectName;
        protected int EffectTime;
        public int publicEffectTime
        {
            get
            {
                return EffectTime;
            }
        }
        public string publicEffectName
        {
            get
            {
                return EffectName;
            }
        }

        protected Effect(string newEffectName, int newEffectTime)
        {
            EffectName = newEffectName;
            EffectTime = newEffectTime;
        }
        public abstract void EffectBegin(Character target);
        public abstract void EffectDoWork(Character target);
        public abstract void EffectEnd(Character target);
        public void IsWorking(Character target)
        {
            if (EffectTime > 0)
            {
                EffectTime--;
                EffectDoWork(target);
                if (EffectTime <= 0)
                {
                    EffectTime = 0;
                    EffectEnd(target);
                }
            }
        }
    }
}
