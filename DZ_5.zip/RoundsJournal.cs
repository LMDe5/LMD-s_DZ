﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal static class RoundsJournal
    {
        private static string[] roundsJournal = new string[100];
        private static int rounds_count = 0;
        public static int RoundsCount => rounds_count;
        private static int fireballCount = 0;
        private static int shieldCount = 0;
        private static int healCount = 0;
        private static int goblinAttackCount = 0;

        private static int totalDamageDealt = 0;
        private static int totalHealingDone = 0;

        public static void newRoundStarted()
        {
            rounds_count++;
        }
        public static void fireballDid()
        {
            fireballCount++;
        }
        public static void shieldDid()
        {
            shieldCount++;
        }
        public static void healDid()
        {
            healCount++;
        }
        public static void goblinAttack()
        {
            goblinAttackCount++;
        }
        public static void damageCounter(int damage)
        {
            totalDamageDealt += damage;
        }
        public static void healCounter(int heal)
        {
            totalHealingDone += heal;
        }

        public static void JournalOfRounds()
        {
            Console.WriteLine($"Сводка по игре:");
            Console.WriteLine($"Всего ходов: {rounds_count}");
            Console.WriteLine();
            Console.WriteLine($"Достижения Мага:");
            Console.WriteLine($"Всего кинуто fireball: {fireballCount}");
            Console.WriteLine($"Всего снаряжено shield: {shieldCount}");
            Console.WriteLine($"Всего выпито зелий здоровья: {healCount}");
            Console.WriteLine($"Всего нанесено урона Гоблину: {totalDamageDealt}");
            Console.WriteLine($"Всего восстановленно здоровья: {totalHealingDone}");
            Console.WriteLine();
            Console.WriteLine($"Достижения Гоблина:");
            Console.WriteLine($"Всего атак гоблина: {goblinAttackCount}");

        }
    }
}
