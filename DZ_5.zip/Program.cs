﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите имя, здоровье и максимальное здоровье мага!");
            string theMageName = StrInput();
            int theMageHealth = IntInput();
            int theMageMaxHealth = IntInput();
            Mage mage = new Mage(theMageName, theMageHealth, theMageMaxHealth);
            Goblin goblin = new Goblin("Гоблин", 100, 100);
            Character[] characters = new Character[2] { mage, goblin };

            
            while (mage.Health > 0 && goblin.Health > 0)
            {
                Console.WriteLine();
                Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - -");
                Console.WriteLine();
                RoundsJournal.newRoundStarted();
                Console.WriteLine($"раунд: {RoundsJournal.RoundsCount}");
                Console.WriteLine();
                Console.WriteLine($"Ход игрока {mage.Name}");
                Console.WriteLine("Доступные заклинания:");
                mage.showSpellBook();
                Console.WriteLine($"Выберите заклинания, введя число от 1 до 3. После выберите цель: 1 - {mage.Name}, 2 - {goblin.Name}");
                mage.spellingSpellBook(IntInput(), characters[IntTargetInput()-1]);

                mage.ProcessEffects(mage);
                goblin.ProcessEffects(goblin);

                if (goblin.Health <= 0)
                {
                    break;
                }
                //---
                Console.WriteLine();
                Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - -");
                Console.WriteLine();
                Console.WriteLine($"Ход игрока {goblin.Name}");
                Console.WriteLine($"{goblin.Name} дерётся руками!");
                mage.applyDamage(20);

                mage.ProcessEffects(mage);
                goblin.ProcessEffects(goblin);
                //---



            }
            Console.WriteLine();
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine();
            RoundsJournal.JournalOfRounds();
            if (mage.Health > 0)
            {
                Console.WriteLine($"Оставшееся здоровье у мага: {mage.Health}");
            }
            else
            {
                Console.WriteLine($"Оставшееся здоровье у гоблина: {goblin.Health}");
            }
        }

        static int IntTargetInput()
        {
            int ovtet;
            while (true)
            {
                Console.WriteLine("Введите 1 или 2:");
                if ((int.TryParse(Console.ReadLine(), out ovtet)) && (ovtet == 1 || ovtet == 2))
                {
                    return ovtet;
                }
                else
                {
                    Console.WriteLine("Был введен неверный формат!");
                }
            }
        }
        static int IntInput()
        {
            int ovtet;
            while (true)
            {
                Console.WriteLine("Введите целое число:");
                if (int.TryParse(Console.ReadLine(), out ovtet))
                {
                    return ovtet;
                }
                else
                {
                    Console.WriteLine("Был введен неверный формат!");
                }
            }
        }

        static string StrInput()
        { 
            while (true)
            {
                string str = Console.ReadLine();
                str.Trim();
                if (str.Length > 0)
                {
                    return str;
                }
                else
                {
                    Console.WriteLine("Введен неверный формат строки!");
                }
            }
        }
    }
}
