﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    abstract class Spell
    {
        protected string SpellName;
        protected string SpellDescription;

        public Spell(string publicSpellName, string publicSpellDescription)
        {
            SpellName = publicSpellName;
            SpellDescription = publicSpellDescription;
        }

        public abstract void Spelling(Character target);

        public void spellShowInfo()
        {
            Console.WriteLine("название заклинания: "+ SpellName + ", его сигнатура: "+ SpellDescription);
        }
    }
}
