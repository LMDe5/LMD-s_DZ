﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Ring : Item, IEquipable, ISellable
    {
        public Ring(string ringName, string ringDiscription) : base(ringName, ringDiscription)
        {
            this.name = ringName;
            this.discription = ringDiscription;
        }
        int ringPrice = 15;
        int ISellable.price => ringPrice;
        public void Sell(Character character)
        {
            Console.WriteLine($"Вы продали {name}");
            character.Inventory.Remove(this);
            character.ApplyGold(ringPrice);
        }
        public void Equip(Character character)
        {
            Console.WriteLine($"вы подобрали {name}");
            character.EquipRing(this);
        }
    }
}
