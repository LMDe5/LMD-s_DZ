﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Gem : Item, ISellable
    {
        public Gem(string Name, string Discription) : base(Name, Discription)
        {
            Name = "драгоценность";
            Discription = "дорогая вещь";
        }
        int gemPrice = 15;
        int ISellable.price => gemPrice;

        public void Sell(Character character)
        {
            Console.WriteLine($"Вы продали {Name}");
            character.ApplyGold(gemPrice);
            character.Inventory.Remove(this);
        }
    }
}
