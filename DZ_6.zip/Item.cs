﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Item
    {
        protected string name;
        protected string discription;
        public string Name => name;
        public string Discription => discription;
        public Item(string Name, string Discription)
        {
            this.name = Name;
            this.discription = Discription;
        }

        public void ShowInfo(Item value)
        {
            Console.WriteLine($"Название предмета: {value.name}");
        }
    }
}
