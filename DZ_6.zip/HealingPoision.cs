﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class HealingPoision : Item, IUsable, IStackable
    {
        public HealingPoision(string Name, string Discription) : base(Name, Discription)
        {
            Name = "зелье";
            Discription = "может лечить";
        }
        public void Use(Character character)
        {
            Console.WriteLine($"персонаж {character.Name} отхилен");
            character.applyHealth(15);
            character.Inventory.Remove(this);
            RemoveOne();
        }
        int stackCount = 1;
        int IStackable.Count => stackCount;

        public void AddOne()
        {
            stackCount++;
        }
        public void RemoveOne()
        {
            if (stackCount > 0)
            {
                stackCount--;
            }
        }

    }
}
