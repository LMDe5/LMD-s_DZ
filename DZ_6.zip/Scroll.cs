﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Scroll : Item, ISellable, IUsable
    {
        public Scroll(string Name, string Discription) : base(Name, Discription)
        {
            this.name = Name;
            this.discription = Discription;
        }
        int scrollPrice = 15;
        int ISellable.price => scrollPrice;
        public void Sell(Character character)
        {
            Console.WriteLine($"Вы продали {name}");
            character.Inventory.Remove(this);
            character.ApplyGold(scrollPrice);
        }
        public void Use(Character character)
        {
            Console.WriteLine($"{name} восстанавливает и здоровье, и энергию!");
            character.applyHealth(5);
            character.ApplyEnergy(5);
            character.Inventory.Remove(this);
        }
    }
}
