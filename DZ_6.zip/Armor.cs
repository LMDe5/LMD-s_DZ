﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Armor : Item, IEquipable
    {
        private int armorProtection;
        public int ArmorProtection => armorProtection;

        public Armor(string armorName, string armorDiscription) : base(armorName, armorDiscription)
        {
            this.name = armorName;
            this.discription = armorDiscription;
        }
        public void Equip(Character character)
        {
            Console.WriteLine($"Вы подняли {name}");
            character.EquipArmor(this);
        }
    }
}
