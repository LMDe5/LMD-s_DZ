﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Weapon : Item, IEquipable
    {
        private int weaponDamage;
        public int WeaponDamage => weaponDamage;

        public Weapon(string weaponName, string weaponDiscription) : base(weaponName, weaponDiscription)
        {
            this.discription = weaponDiscription;
            this.name = weaponName;
        }
        public void Equip(Character character)
        {
            Console.WriteLine($"Вы подняли {name}");
            character.EquipWeapon(this);
        }
    }
}
