﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Character
    {
        protected string name;
        protected int health;
        protected int maxHealth;
        //---
        protected int energy = 0;
        protected int maxEnergy = 100;
        protected int goldCount;
        protected Weapon weapon;
        protected Armor armor;
        protected Ring ring;

        public Armor Armor { get { return armor; } }
        public Weapon Weapon { get { return weapon; } }

        public int Health
        {
            get
            { return health; }
        }
        public string Name
        {
            get
            {
                return name;
            }
        }

        private Inventory inventory;
        public Inventory Inventory => inventory;
        public Character(string publicName, int publicHealth, int publicMaxHealth)
        {
            name = publicName;
            health = publicHealth;
            maxHealth = publicMaxHealth;
            inventory = new Inventory();
        }
        public virtual void applyHealth(int NewHealth)
        {
            if (health + NewHealth > maxHealth)
            {
                health = maxHealth;
                Console.WriteLine($"Игрок {Name} восстановил здоровье до полного значения ({maxHealth})!");
            }
            else
            {
                health = health + NewHealth;
                Console.WriteLine($"Игрок {Name} восстановил здоровье, оно равняется: {health}!");
            }
        }
        public virtual void ApplyEnergy(int value)
        {
            if (energy + value > maxEnergy)
            {
                energy = maxEnergy;
                Console.WriteLine($"Игрок {Name} восстановил энергию до полного значения ({maxEnergy})!");
            }
            else
            {
                energy = energy + value;
                Console.WriteLine($"Игрок {Name} восстановил энергию, оно равняется: {energy}!");
            }
        }

        public virtual void ApplyGold(int value)
        {
            if (goldCount + value < 0)
            {
                goldCount = 0;
                Console.WriteLine($"Вы потеряли все золото! Кол-во золота в вашем инвенторе: 0");
                return;
            }
            goldCount = goldCount + value;
            Console.WriteLine($"Значение золота в вашем инвенторе обновилось! Оно равняется: {goldCount}");
        }
        public virtual void EquipWeapon(Weapon item)
        {
            if (item is Weapon)
            {
                weapon = item;
            }
        }
        public virtual void EquipRing(Ring newRing)
        {
            ring = newRing;
        }

        public virtual void EquipArmor(Armor newArmor)
        {
            armor = newArmor;
        }
        public virtual void UnEquipWeapon()
        {
            weapon = null;
        }
        public virtual void UnEquipArmor()
        {
            armor = null;
        }
        public void ShowInfo()
        {
            Console.WriteLine($"Имя персонажа: {name}");
            Console.WriteLine($"Оставшееся здоровье персонажа: {health}");
            Console.WriteLine($"Оставшееся энергия персонажа: {energy}");
            Console.WriteLine($"Оставшееся кол-во золота персонажа: {goldCount}");
            if (weapon != null)
            {
                Console.WriteLine($"У персонажа есть оружие: {weapon}");
            }
            if (armor != null)
            {
                Console.WriteLine($"У персонажа есть броня: {armor}");
            }
        }
    }
}
