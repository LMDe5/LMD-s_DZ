﻿using IMIMIMIMANIMO__dz4_;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PitiPiriPiPiPi
{
    internal interface IEquipable
    {
        void Equip(Character user);
    }
}
