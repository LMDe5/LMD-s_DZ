﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Food : Item, IUsable, IStackable
    {
        public Food(string Name, string Discription) : base(Name, Discription)
        {
            Name = "еда";
            Discription = "ее можно сскушать";
        }
        public void Use(Character character)
        {
            Console.WriteLine("вы покушали, востановив энергию");
            character.ApplyEnergy(15);
            character.Inventory.Remove(this);
            RemoveOne();
        }
        int stackCount = 1;

        int IStackable.Count => stackCount;

        public void AddOne()
        {
            stackCount++;
        }
        public void RemoveOne()
        {
            if (stackCount > 0)
            {
                stackCount--;
            }
        }
    }
}
