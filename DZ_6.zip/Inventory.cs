﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Inventory
    {
        List<Item> items = new List<Item>();
        private int maxItemsLenght = 100;

        public void Add(Item item)
        { 
            if (items.Count < maxItemsLenght)
            {
                if (item is IStackable)
                {
                    bool sameFounded = false;
                    for (int i = 0; i < items.Count; i++)
                    {
                        if (item.Name == items[i].Name && items[i] is IStackable newStackableItem)
                        {
                            newStackableItem.AddOne();
                            Console.WriteLine($"Предмет {item.Name} уже есть в инвенторе. Добавим новый в стак, их кол-во: {newStackableItem.Count}");
                            sameFounded = true;
                            break;
                        }
                    }
                    if (sameFounded==false)
                    {
                        items.Add(item);
                        Console.WriteLine("Предмет добавлен в инвентарь");
                    }
                }
                else
                {
                    items.Add(item);
                    Console.WriteLine("Предмет добавлен в инвентарь");
                }
            }
        }
        public void Remove(Item item)
        {
            if (item is IStackable stackableItem)
            {
                stackableItem.RemoveOne();
                if (stackableItem.Count < 1)
                {
                    items.Remove(item);
                }
            }
            else
            {
                items.Remove(item);
            }
            
        }
        public void RemoveAt(int index)
        {
            if (index < items.Count && index >= 0)
            {
                items.RemoveAt(index);
            }
        }
        public Item GetItem(int index)
        {
            if (index >= 0 && index < items.Count)
            {
                Item value = items[index];
                return value;
            }
            return null;
        }
        public void ShowInventory()
        {
            Console.WriteLine("Содержимое инвенторя:");
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i] is IStackable stackableItem && stackableItem.Count > 1)
                {
                    Console.WriteLine($"[{i}] x{stackableItem.Count} {items[i].Name} - {items[i].Discription}");
                }
                else
                {
                    Console.WriteLine($"[{i}] {items[i].Name} - {items[i].Discription}");
                }
            }
        }
        
        public int InventoryCount()
        {
            return items.Count;
        }
    }
}
