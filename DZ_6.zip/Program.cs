﻿using IMIMIMIMANIMO__dz4_;
using Microsoft.Win32;
using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Character character = new Character("Piti", 100, 100);
            Item item1 = new Gem("камешек", "красивый");
            Item item2 = new OldBoot("старый ботинок", "дырявый");
            Item item3 = new Gem("камешек", "красивый");
            Item item4 = new HealingPoision("желтое зелье", "точно ли это зелье?");
            Item item5 = new HealingPoision("желтое зелье", "точно ли это зелье?");
            Item item6 = new Weapon("меч", "имеет красивую форму");
            Item item7 = new Armor("броня", "имеет защиту древних Архонтов");
            Item item8 = new Food("доширак", "пища студентов или богов");
            Item item9 = new Food("доширак", "пища студентов или богов");
            Item item10 = new Ring("магическое кольцо", "и вспомогательное, и продаваемое");
            Item item11 = new Scroll("древний посох", "о-о-о-о-о-о-очень дрвений");
            character.Inventory.Add(item1);
            character.Inventory.Add(item2);
            character.Inventory.Add(item3);
            character.Inventory.Add(item4);
            character.Inventory.Add(item5);
            character.Inventory.Add(item6);
            character.Inventory.Add(item7);
            character.Inventory.Add(item8);
            character.Inventory.Add(item9);
            character.Inventory.Add(item10);
            character.Inventory.Add(item11);


            // 1
            character.ShowInfo();
            Console.WriteLine();

            

            while (true)
            {      
                // 2
                character.Inventory.ShowInventory();
                Console.WriteLine(); 
                
                //3
                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1 — Использовать предмет");
                Console.WriteLine("2 — Экипировать предмет");
                Console.WriteLine("3 — Продать предмет");
                Console.WriteLine("4 — Выбросить предмет");
                Console.WriteLine("0 — Выход");
                int choised = ChoiseIntInput();
                if (choised == 0)
                {
                    Console.WriteLine("Выход из программы :з...");
                    return;
                }
                Console.WriteLine("Отличный выбор!");
                Item choisedItem;
                while (true)
                {
                    Console.WriteLine("Введите ИНДЕКС предмета!");
                    int index = IntInput();
                    choisedItem = character.Inventory.GetItem(index);
                    if ( choisedItem == null)
                    {
                        Console.WriteLine("предмет не был найден!");
                    }
                    else
                    {
                        break;
                    }
                }
                
                Console.WriteLine();

                if (choised == 1)
                {
                    if (choisedItem is IUsable usable)
                    {
                        usable.Use(character);
                    }
                    else
                    {
                        Console.WriteLine("Данный предмет нельзя Использовать");
                    }
                }
                if (choised == 2)
                {
                    if (choisedItem is IEquipable equipable)
                    {
                        equipable.Equip(character);
                    }
                    else
                    {
                        Console.WriteLine("Данный предмет нельзя Экипировать");
                    }
                }
                if (choised == 3)
                {
                    if (choisedItem is ISellable sellable)
                    {
                        sellable.Sell(character);
                    }
                    else
                    {
                        Console.WriteLine("Данный предмет нельзя Продать");
                    }
                }
                if (choised == 4)
                {
                    if (choisedItem is IDiscardable discardable)
                    {
                        discardable.Discard(character);
                    }
                    else
                    {
                        Console.WriteLine("Данный предмет нельзя Выбросить");
                    }
                }

                Console.WriteLine();
                Console.WriteLine("--- --- --- --- --- --- --- --- --- --- --- --- --- --- ---");
                Console.WriteLine();

                if (character.Inventory.InventoryCount() <= 0)
                {
                    Console.WriteLine("Инвентарь пуст!");
                    return;
                }
            }
        }

        static int ChoiseIntInput()
        {
            int result;
            while (true)
            {
                Console.WriteLine("Введите целое число от 0 до 4:");
                if (int.TryParse(Console.ReadLine(), out result))
                {
                    if (result >= 0 && result <= 4)
                    {
                        return result;
                    }
                }
                else
                {
                    Console.WriteLine("Был введен неверный формат!");
                }
            }
        }
        static int IntInput()
        {
            int result;
            while (true)
            {
                Console.WriteLine("Введите целое число:");
                if (int.TryParse(Console.ReadLine(), out result))
                {
                    if (result >= 0 && result < 100)
                    {
                        return result;
                    }
                }
                else
                {
                    Console.WriteLine("Был введен неверный формат!");
                }
            }
        }
    }
}
