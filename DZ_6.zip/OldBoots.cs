﻿using PitiPiriPiPiPi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMIMIMIMANIMO__dz4_
{
    internal class OldBoot : Item, IDiscardable
    {
        public OldBoot(string Name, string Discription) : base(Name, Discription)
        {
            Name = "Ботинок";
            Discription = "дырявый мусор";
        }
        public void Discard(Character character)
        {
            Console.WriteLine($"{Name} выкинут");
            character.Inventory.Remove(this);
        }



    }
}
