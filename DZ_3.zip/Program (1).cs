﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics.SymbolStore;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork1
{
    internal class Program
    {
        //static void print(string message)
        //{
        //    Console.WriteLine(message);
        //}

        //static int addFive(int newNumber = 10)
        //{
        //    return newNumber + 5;
        //}

        //static int addFive()
        //{
        //    return 60 + 5;
        //}

        //static int fact(int n)
        //{
        //    if (n <= 1)
        //    {
        //        return 1;
        //    }

        //    int correct = n * fact(n - 1);

        //    Console.WriteLine($"пиписька: {correct}");
        //    return correct;
        //}
        static void Main(string[] args)
        {
            Console.WriteLine("Lvl 1");
            Console.WriteLine("1. Введите число, которое будет посчитано по модулю:");
            int number;
            if (int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine(ABS(number));
            }
            else
            {
                Console.WriteLine("Вы ввели строку!");
            }

            Console.WriteLine("2. Введите три числа:");
            int num1;
            int num2;
            int num3;
            if (int.TryParse(Console.ReadLine(), out num1))
            {
                if (int.TryParse(Console.ReadLine(), out num2))
                {
                    if (int.TryParse(Console.ReadLine(), out num3))
                    {
                        Console.WriteLine($"Максимальное число из трёх введенных: {Max3(num1, num2, num3)}");
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели строку!");
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели строку!");
                }
            }
            else
            {
                Console.WriteLine("Вы ввели строку!");
            }

            Console.WriteLine("3. Введите символ!");
            string symbol = Console.ReadLine();
            Console.WriteLine("3. Введите количество повторений!");
            int count;
            if (int.TryParse(Console.ReadLine(), out count))
            {
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }
            PrintLine(symbol, count);

            Console.WriteLine("Lvl 2");
            Console.WriteLine("4. Введите символ!");
            string text = Console.ReadLine();
            Console.WriteLine("4. Введите количество повторений!");
            int times;
            if (int.TryParse(Console.ReadLine(), out times))
            {
                Console.WriteLine(Repeat(text, times));
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }
            

            Console.WriteLine("5. Введите строку!");
            string s = Console.ReadLine();
            Console.WriteLine("5. Введите символ, который будет искаться в ранее введенной строке!");
            char ch;
            if (Char.TryParse(Console.ReadLine(), out ch))
            {
            }
            else
            {
                Console.WriteLine("Вы ввели не один символ!");
            }
            if (TryIndexOf(s, ch, out int index))
            {
                Console.WriteLine($"Найден первый символ в строке! Его индекс равен: {index}");
            }
            else
            {
                Console.WriteLine("Символ не найден");
            }


            Console.WriteLine("6. Введите число, ограничитель снизу, ограничитель сверху!");
            int value;
            int numere1;
            int numere2;
            if (int.TryParse(Console.ReadLine(), out value))
            {
                if (int.TryParse(Console.ReadLine(), out numere1))
                {
                    if (int.TryParse(Console.ReadLine(), out numere2))
                    {
                        Clamp(ref value, numere1, numere2);
                        Console.WriteLine(value);
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели не число!");
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не число!");
                }
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }

            Console.WriteLine("Lvl 3");
            Console.WriteLine("7. Введите строку, которая будет перевёрнута!");
            string str7 = Console.ReadLine();
            Console.WriteLine(ReverseRec(str7));

            Console.WriteLine("8. Введите число, сумма цифр которого будет посчитана по его модулю!");
            int n = 0;
            if (int.TryParse(Console.ReadLine(), out n))
            {
                Console.WriteLine(SumDigitsRec(n));
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }

            Console.WriteLine("9. Введите три числа!");
            int TRIa;
            int TRIb;
            int TRIc;
            if (int.TryParse(Console.ReadLine(), out TRIa))
            {
                if (int.TryParse(Console.ReadLine(), out TRIb))
                {
                    if (int.TryParse(Console.ReadLine(), out TRIc))
                    {
                        IsTriangle(TRIa, TRIb, TRIc);
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели не число!");
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не число!");
                }
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }

            Console.WriteLine("Lvl 4");
            Console.WriteLine("10. Введите число, степень числа");
            int a10;
            int n10;
            if (int.TryParse(Console.ReadLine(), out a10))
            {
                if (int.TryParse(Console.ReadLine(), out n10))
                {
                    if (n10 >= 0)
                    {
                        Console.WriteLine(PowFast(a10, n10));
                        Console.WriteLine($"Кол-во шагов в быстром возведении в степень: {cnt_of_PowFast}");
                        Console.WriteLine(PowRec(a10, n10));
                        Console.WriteLine($"Кол-во шагов в обычном возведении в степень: {cnt_of_PowRec}");
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели отрицательное значение!");
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не число!");
                }
            }
            else
            {
                Console.WriteLine("Вы ввели не число!");
            }

            Console.WriteLine("11. Введите строку");
            string str = Console.ReadLine();
            Console.WriteLine(CompressRuns(str));


        }
        static int ABS(int x)
        {
            if (x > 0)
            {
                return x;
            }
            else
            {
                return -x;
            }
        }

        static int Max3(int a, int b, int c)
        {
            if (a > b)
            {
                if (a > c)
                {
                    return a;
                }
            }
            else
            {
                if (b > c)
                {
                    return b;
                }
            }
            return c;
        }

        static void PrintLine(string symbol = "*", int count = 10)
        {
            string str = "";
            for (int i = 0; i < count; i++)
            {
                str = str + symbol + " ";
            }
            Console.WriteLine(str);
        }

        static string Repeat(string text, int times = 3)
        {
            string str = "";
            for (int i = 0; i < times; i++)
            {
                str = str + text;
            }
            return str;
        }

        static bool TryIndexOf(string s, char ch, out int index)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ch)
                {
                    index = i;
                    return true;
                }
            }
            index = -1;
            return false;
        }

        static void Clamp(ref int value, int min, int max)
        {
            if (value < min)
            {
                value = min;
            }
            if (value > max)
            {
                value = max;
            }

        }

        static string ReverseRec(string s, string reversed_str = "", int position = 0)
        {
            if (position >= s.Length)
            {
                return reversed_str;
            }
            reversed_str = reversed_str + s[s.Length - 1 - position];
            
            return ReverseRec(s, reversed_str, position + 1);
        }
        public static int position;
        public static int summa;
        static int SumDigitsRec(int n)
        {
            int new_n = ABS(n);
            string str_n = new_n.ToString();
            if (position >= str_n.Length)
            {
                return summa;
            }
            summa = int.Parse(str_n[position].ToString()) + summa;
            position++;
            return SumDigitsRec(n);
        }
         
        static bool IsTriangle(in int a, in int b, in int c)
        {
            if ((a + b > c) && (a + c > b) && (b + c > a))
            {
                Console.WriteLine("Введенные числа являются сторонами какого-то треугольника");
                return true;
            }
            Console.WriteLine("Введенные числа не являются длинами сторон треугольника");
            return false;
        }
        private static int cnt_of_PowFast = 0;
        static int PowFast(int a, int n)
        {
            cnt_of_PowFast++;
            if (n == 0)
            {
                return 1;
            }
            if (n % 2 == 0)
            {
                int new_valid = PowFast(a, n/2);
                return new_valid * new_valid;
            }
            else
            {
                return a * PowFast(a, n-1);
            }
            
        }
        private static int cnt_of_PowRec = 0;
        static int PowRec(int a, int n)
        {
            cnt_of_PowRec++;
            if (n == 0)
            {
                return 1;
            }
            if (n == 1)
            {
                return a;
            }
            else
            {
                
                return a * PowRec(a, n - 1);
            }
        }

        static string CompressRuns(string s, int position = 0, string str = "")
        {   
            if (position >= s.Length)
            {
                return str;
            }
            if (position == 0 || s[position] != s[position - 1])
            {
                return CompressRuns(s, position + 1, str + s[position]);
            }
            else
            {
                return CompressRuns(s, position + 1, str);
            }
            
        }
    }
}
