﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace svipipipi
{
    //9
    internal class Player
    {
        private string name;
        private PlayerInventory inventory;

        public Player()
        {
            this.name = name;
            this.inventory = new PlayerInventory(); //<---
        }

        //10
        public void PickUpItem(Item item)
        {
            inventory.AddItem(item);
        }
        //11
        public void ShowInventory()
        {
            inventory.ShowAllItems();
        }

        //14
        public int GetInventoryValue()
        {
            return inventory.GetTotalPrice();
        }
    }
}
