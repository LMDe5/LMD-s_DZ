﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace svipipipi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //4
            Item[] array = new Item[2];
            array[0] = new Item("Котик", 400, 3.5f);
            array[1] = new Item("Собачка", 400, 50.5f);

            for (int i = 0; i < array.Length; i++)
            {
                array[i].DisplayInfo();
            }

            //8
            PlayerInventory inventory = new PlayerInventory();
            Item item_cup_of_tea = new Item("Кружка чая", 200, 15.2f);
            Item item_gleb = new Item("Глеб", 15, 20.8f);
            Item item_phone = new Item("Телефон", 500, 5f);
            inventory.AddItem(item_cup_of_tea);
            inventory.AddItem(item_gleb);
            inventory.AddItem(item_phone);
            Console.WriteLine($"Суммарно добавленный вес в рюкзак:{inventory.GetTotalWeight()}");

            //12
            Player player = new Player();
            Item item_glasses = new Item("Очки", 300, 1.5f);
            Item item_candy = new Item("Конфета", 15, 0.5f);
            Item item_IHMAWTLA = new Item("ЯНСИБНХЖ", 50, 14.8f);
            Item item_notebook = new Item("Ноутбук", 500, 30f);
            player.PickUpItem(item_glasses);
            player.PickUpItem(item_candy);
            player.PickUpItem(item_IHMAWTLA);
            player.PickUpItem(item_notebook);
            player.ShowInventory();

            //15
            Console.WriteLine($"Суммарная сумма предметов в рюкзаке равна: {player.GetInventoryValue()}");
        }
    }
}