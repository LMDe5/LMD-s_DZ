﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace svipipipi
{
    //5
    internal class PlayerInventory
    {
        private Item[] items = new Item[5];
        private float WeightCapacity = 40f;
        private float CurrentWeight = 0f;
        //6
        public void AddItem(Item item)
        {
            if (CurrentWeight + item.HasWeight >  WeightCapacity)
            {
                Console.WriteLine("Предмет слишком тяжелый!");
                return;
            }
            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] == null)
                {
                    items[i] = item;
                    CurrentWeight += item.HasWeight;
                    Console.WriteLine($"Предмет добавлен в рюкзак по индексу: {i}");
                    return;
                }
            }
            Console.WriteLine("В рюкзаке нет места!");
        }
        //7
        public float GetTotalWeight()
        {
            return CurrentWeight;
        }

        //11
        public void ShowAllItems()
        {
            int not_empty = 0;
            for (int i = 0; i < items.Length;i++)
            {
                if (items[i] != null)
                {
                    not_empty++;
                    Console.WriteLine($"Предмет в рюкзаке под индексом {i} называется {items[i].HasName}, имеет цену {items[i].HasPrice}, весит {items[i].HasWeight}");
                }
            }
            if (not_empty == 0)
            {
                Console.WriteLine("Рюкзак пустой");
            }
        }

        //13
        public int GetTotalPrice()
        {
            int not_empty = 0;
            int total_price = 0;
            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    total_price += items[i].HasPrice;
                    not_empty ++;
                }
            }
            return total_price;
        }
    }

}
