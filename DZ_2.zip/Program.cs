﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics.SymbolStore;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I <3 MineCraft :)");

            //int[] ages2 = new int[5] { 1, 3, 6, 7, 9 };

            //for (int i = 0; i <= ages2.Length; i++)
            //{
            //    Console.WriteLine(ages2[i]);
            //}

            //int minValue = ages2[0];
            //int maxValue = ages2[0];

            //for (int i = 0; i < ages2.Length; i++)
            //{
            //    if (minValue > ages2[i])
            //    {
            //        minValue = ages2[i];
            //    }
            //    if (maxValue < ages2[i])
            //    {
            //        maxValue = ages2[i];
            //    }
            //}   

            //int[] ages = new int[5] { 1, 3, 6, 7, 9 };

            //int[] ages2 = new int[ages.Length-1];

            //for (int i = 1; i < ages2.Length; i++) 
            //{
            //    ages2[i] = ages[i];
            //}

            //ages = ages2;

            //for (int i = 0; i < ages.Length; i++)
            //{
            //    Console.WriteLine(ages[i]);
            //}
            Console.WriteLine("Lvl 1");
            Console.WriteLine("Введите число:");
            string a = Console.ReadLine();
            int New_a = int.Parse(a);
            New_a = New_a + 100;
            Console.WriteLine(New_a);

            double b1 = ((double)7 / 2);
            int b2 = ((int)7.0 / 2);
            Console.WriteLine($"b1 = {b1}; b2 = {b2}");
            if (b1 > b2)
            {
                
                Console.WriteLine($"{b1} > {b2}");
            }
            else 
            {
                
                Console.WriteLine($"{b1} < {b2}");
            }

            Console.WriteLine("Введите строку:");
            string c1 = Console.ReadLine();
            int c2 = 0;
            if (int.TryParse(c1, out c2)) 
            {
                Console.WriteLine(c2 * c2);
            }
            else
            {
                Console.WriteLine("Вы ввели строку с буквами. Нужны лишь числа!");
            }

            Console.WriteLine("Введите дробное число:");
            double d1 = double.Parse(Console.ReadLine());
            int d2 = (int)d1;
            if (d1 < d2)
            {
                Console.WriteLine($"Ваше число было: {d1}; его целочисленное значение: {d2}. {d2} > {d1}");
            }
            else
            {
                Console.WriteLine($"Ваше число было: {d1}; его целочисленное значение: {d2}. {d1} > {d2}");
            }

            Console.WriteLine("Lvl 2");



            int[] la = new int[5] { 1, 3, 5, 7, 13};
            int titi = 0;
            string poska = $"числа массива: ";
            for (int i = 0; i < la.Length; i++)
            {
                titi = (int)la[i];
                poska = poska + titi.ToString() + " " ;
            }
            Console.WriteLine($"{poska}");

            int chetn = 0;
            int chetn_count = 0;
            for (int i = 0; i < la.Length; i++) 
            {
                chetn = (int)la[i];
                if (chetn % 2 == 0)
                {
                    chetn_count++;
                }
            }
            Console.WriteLine($"кол-во четных чисел в массиве: {chetn_count}");

            int summa = 0;
            int count = 0;
            int position = 0;
            for (int i = 0; i < la.Length; i++)
            {
                position = (int)la[i];
                summa = summa + position;
                count ++;
            }
            double sr_aref = (double)summa / count;
            Console.WriteLine($"сумма чисел массива: {summa}, ср. Арифметическое: {sr_aref}");

            int firstValue = la[0];
            int lastValue = la[la.Length-1];
            int vremfirst = 0;
            vremfirst = firstValue;
            la[0] = lastValue;
            la[la.Length - 1] = vremfirst;
            Console.WriteLine("Были заменены первый и последний элементы массива! Теперь массив таков:");
            int titi0 = 0;
            string poska0 = $"числа массива: ";
            for (int i = 0; i < la.Length; i++)
            {
                titi0 = (int)la[i];
                poska0 = poska0 + titi0.ToString() + " ";
            }
            Console.WriteLine($"{poska0}");

            int maxValue = la[0];
            int maxElem = 0;
            int minValue = la[0];
            int minElem = 0;
            int temp = 0;
            for (int i = 1; i < la.Length; i++)
            {
                if (minValue > la[i])
                {
                    minValue = la[i];
                    minElem = i;
                }
                if (maxValue < la[i])
                {
                    maxValue = la[i];
                    maxElem = i;
                }
            }
            Console.WriteLine($"максимальный элемент массива: {maxElem}; его индекс: {maxValue}");
            Console.WriteLine($"минимальный элемент массива: {minElem}; его индекс: {minValue}");


            Console.WriteLine("Lvl 3");
            int[] massa = new int[10] { 1, 2, 3, 4, 5, 0, 0, 0, 0, 0 };
            Console.WriteLine($"Массив Масса выглядит так: ");
            string strok = "";
            for (int i = 0; i < massa.Length; i++)
            {
                strok = strok + massa[i].ToString() + " ";
            }
            Console.WriteLine($"{strok}");

            for (int i = 5;  i < massa.Length; i++)
            {
                Console.WriteLine($"Введите число, чтобы заменить число с индексом {i}");
                massa[i] = int.Parse(Console.ReadLine());

            }
            Console.WriteLine($"Теперь массив Масса выглядит так: ");
            string strok2 = "";
            for (int i = 0; i < massa.Length; i++)
            {
                strok2 = strok2 + massa[i].ToString() + " ";
            }
            Console.WriteLine($"{strok2}");
            int[] massa_2 = new int[massa.Length * 2];
            Console.WriteLine("Предыдущий массив заполнен! Создан новый массив!");
            Console.WriteLine("Новый массив имеет следущие значения:");
            for (int i = 0; i < 10; i++)
            {
                massa_2[i] = massa[i];
            }
            string massa_2str = "";
            for (int i = 0; i < massa_2.Length; i++)
            {
                massa_2str = massa_2str + massa_2[i].ToString() + " ";
            }
            Console.WriteLine(massa_2str);

            Console.WriteLine("Был удалён элемент с индексом 3! Теперь массив имеет такой вид:");
            int deleteStat = 3;
            int[] massa_3 = new int[massa_2.Length-1];
            int cnt_of_replace = 0;
            for (int i = 0; i < massa_3.Length; i++)
            {
                if (i != deleteStat)
                {
                    massa_3[cnt_of_replace] = massa_2[i];
                    cnt_of_replace++;
                }
            }
            massa_2 = massa_3;
            string new_str = "";
            for (int i = 0; i < massa_2.Length; i++)
            {
                new_str = new_str + massa_2[i].ToString() + " ";
            }
            Console.WriteLine(new_str);

            Console.WriteLine("--- --- --- --- --- --- --- --- --- --- ---");
            Console.WriteLine("начинаем работу с новым массивом: 1 2 3 5 7 11 13");
            int[] new_massa = new int[7] { 1, 2, 3, 5, 7, 11, 13 };
            int[] new_massa_TIK = new int[new_massa.Length-1];
            Console.WriteLine("Был удалён элемент с индексом 4! На место удаленного элемента встал последний:");
            int last_index = new_massa[new_massa.Length-1];
            for (int i = 0; i < new_massa_TIK.Length; i++)
            {
                if (i != 4)
                {
                    new_massa_TIK[i] = new_massa[i];
                }
                else
                {
                    new_massa_TIK[i] = last_index;
                }
            }
            new_massa = new_massa_TIK;
            string new_massa_str = "";
            for (int i = 0;i < new_massa.Length;i++)
            {
                new_massa_str = new_massa_str + new_massa[i] + " ";
            }
            Console.WriteLine(new_massa_str);

            Console.WriteLine("Введите число, которое должно быть уничтожен ♥ из массива:");
            int deleteIndex = int.Parse(Console.ReadLine());
            int[] new_massa_TIK2 = new int[new_massa.Length ];
            for (int i = 0; i < new_massa_TIK2.Length; i++)
            {
                if (new_massa[i] != deleteIndex)
                {
                    new_massa_TIK2[i] = new_massa[i];
                }
            }
            new_massa = new_massa_TIK2;
            string new_massa_str2 = "";
            for (int i = 0; i < new_massa.Length; i++)
            {
                new_massa_str2 = new_massa_str2 + new_massa[i] + " ";
            }
            Console.WriteLine(new_massa_str2);


            Console.WriteLine("Lvl 4. The Hellest Hell Of The Heaven..");
            Console.WriteLine("Начинаем работу с массивом 1 2 3 5 7 11 13");
            int[] mass7 = new int[7] { 1, 2, 3, 5, 7, 11, 13 };
            int[] mass7TIK = new int[mass7.Length];
            int penis = mass7.Length-1;
            for (int i = 0; i < mass7.Length;i++)
            {
                mass7TIK[i] = mass7[penis - i];
            }
            mass7 = mass7TIK;
            string mass7_str = "";
            for (int i = 0; i < mass7.Length;i++)
            {
                mass7_str = mass7_str + mass7[i] + " ";
            }
            Console.WriteLine("Развернём наш массив!");
            Console.WriteLine(mass7_str);

            int check_polindrom = 0;
            for (int i = 0; i < mass7.Length; i++)
            {
                if (mass7[i] == mass7[penis - i])
                {
                    check_polindrom++;
                }
            }
            if (check_polindrom == mass7.Length)
            {
                Console.WriteLine("Массив является полиндромом");
            }
            else
            {
                Console.WriteLine("Массив не является полиндромом");
            }

            Console.WriteLine("--- --- --- --- --- --- --- --- --- --- ---");
            Console.WriteLine("Начинаем работу с новым масивом!");
            int[] mass16 = new int[10];
            for (int i = 0; i < mass16.Length;i++)
            {
                Console.WriteLine($"{i+1}. Введите число, которое должно находиться в новом массиве!");
                mass16[i] = int.Parse(Console.ReadLine()); 
            }
            string mass16_str = "";
            for (int i = 0; i < mass16.Length;i++)
            {
                mass16_str = mass16_str + mass16[i].ToString() + " ";
            }
            Console.WriteLine($"Были внесены следующие данные в массив: {mass16_str}");
            Console.WriteLine($"Сожмём массив... Сожмём массив... Сожмём массив...");
            int counter = 1;
            for (int i = 1; i < mass16.Length;i++)
            {
                if (mass16[i] != mass16[i-1])
                {
                    counter++;
                }
            }
            int[] new_mass16 = new int[mass16.Length];
            new_mass16[0] = mass16[0];
            int unic_counter = 1;
            for (int i = 1; i < mass16.Length;i++)
            {
                if (mass16[i] != mass16[i-1])
                {
                    new_mass16[unic_counter] = mass16[i];
                    unic_counter++;
                }
            }
            int[] zip_mass16 = new int[unic_counter];
            for (int i = 0; i < zip_mass16.Length;i++)
            {
                zip_mass16[i] = new_mass16[i];
            }
            string zip_mass16_str = "";
            for (int i = 0; i < zip_mass16.Length; i++)
            {
                zip_mass16_str = zip_mass16_str + zip_mass16[i].ToString() + " ";
            }
            Console.WriteLine(zip_mass16_str);
        }
    }
}
